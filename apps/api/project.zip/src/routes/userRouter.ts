import { schema } from '../db.ts'
import { protectedProcedure, router } from '../index.ts'
import { userSchema } from '../models/user.ts'
import { createDummyUser } from '../useCases/createUser.ts'

export const createUserRouter = () =>
	router({
		getUsers: protectedProcedure.query(async ({ ctx: { db } }) => {
			console.log('problem?')
			return await db.select().from(schema.users)
		}),
		createUser: protectedProcedure
			.input(userSchema.assert)
			.mutation(async ({ input, ctx: { db } }) => {
				const user = await createDummyUser(input, db)
				return user
			}),
	})
