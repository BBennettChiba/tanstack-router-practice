import { type } from 'arktype'
import { publicProcedure, router } from '../index.ts'

export const createHelloRouter = () => {
	return router({
		hello: publicProcedure
			.input(type('string | undefined').assert)
			.query(({ input }) => {
				return `Hello ${input ?? 'World'}!`
			}),
	})
}
