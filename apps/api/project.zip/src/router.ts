import { initTRPC } from '@trpc/server'
import { Hono } from 'hono'
import { cors } from 'npm:hono/cors'
import { trpcServer } from '@hono/trpc-server'
import { AuthInstance, type Session } from './auth.ts'
import superjson from 'superjson'
import { PostgresJsDatabase } from 'drizzle-orm/postgres-js/driver'
import { AppRouter } from './index.ts'
import { getRoutes } from './routes/index.ts'

interface Context {
	session?: Session
	db: PostgresJsDatabase
}

const createTrpc = () => {
	const trpc = initTRPC.context<Context>().create({ transformer: superjson })

	return trpc
}

const createAppRouter = (t: ReturnType<typeof createTrpc>, routes: ReturnType<typeof getRoutes>) => {
	const appRouter = t.mergeRouters(routes)

	return appRouter
}

const createTrpcApp = (db: PostgresJsDatabase, auth: AuthInstance, appRouter: AppRouter) => {
	const trpcApp = new Hono()

	trpcApp.use(
		'/trpc/*',
		cors({
			origin: 'http://localhost:5173', // replace with your origin
			allowHeaders: ['Content-Type', 'Authorization'],
			allowMethods: ['POST', 'GET', 'OPTIONS'],
			exposeHeaders: ['Content-Length'],
			maxAge: 600,
			credentials: true,
		}),
	)

	trpcApp.use(
		'/trpc/*',
		trpcServer({
			router: appRouter,
			createContext: async (_, c) => {
				const session = await auth.api.getSession({
					headers: c.req.raw.headers,
				})
				return {
					session: session,
					db,
				}
			},
		}),
	)
	return trpcApp
}

export { createAppRouter, createTrpc, createTrpcApp }
