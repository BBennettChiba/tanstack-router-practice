import { PostgresJsDatabase } from 'drizzle-orm/postgres-js/driver'
import { InsertUser, schema } from '../db.ts'

export async function createDummyUser(data: InsertUser, db: PostgresJsDatabase) {
	await db.insert(schema.users).values(data)
}
