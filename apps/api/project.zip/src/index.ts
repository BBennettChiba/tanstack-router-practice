import { Hono } from 'hono'
import { cors } from 'npm:hono/cors'
import { createClient, createDb } from './db.ts'
import { createAppRouter, createTrpc, createTrpcApp } from './router.ts'
import env from './env.ts'
import { createAuth } from './auth.ts'
import { getRoutes } from './routes/index.ts'

const app = new Hono()

const db = createDb(createClient(env.DATABASE_URL))

const auth = createAuth(db)

const trpc = createTrpc()

export const router = trpc.router
export const publicProcedure = trpc.procedure
export const protectedProcedure = trpc.procedure.use(function isAuth(opts) {
	const { ctx } = opts
	if (!ctx.session) {
		throw new TRPCError({ code: 'UNAUTHORIZED' })
	}
	return opts.next(opts)
})

const routes = getRoutes(trpc)

const appRouter = createAppRouter(trpc, routes)

const trpcApp = createTrpcApp(db, auth, appRouter)

app.use(
	'/api/auth/**', // or replace with "*" to enable cors for all routes
	// "*",
	cors({
		origin: 'http://localhost:5173', // replace with your origin
		allowHeaders: ['Content-Type', 'Authorization'],
		allowMethods: ['POST', 'GET', 'OPTIONS'],
		exposeHeaders: ['Content-Length'],
		maxAge: 600,
		credentials: true,
	}),
)

app.on(['POST', 'GET'], '/api/auth/**', (c) => {
	return auth.handler(c.req.raw)
})

app.route('/', trpcApp)

console.log(`Server is running on http://localhost:${env.PORT}`)
console.log(`Database URL: ${env.DATABASE_URL}`)

Deno.serve({ port: env.PORT }, app.fetch)

export type AppRouter = typeof appRouter
